package com.example.githubuserapp

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.LinearLayout
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import kotlinx.android.synthetic.main.activity_main.*

class MainActivity : AppCompatActivity() {

    companion object {
        const val EXTRA_PARCELDATA = "000"
    }

    private lateinit var userList: ArrayList<UserModel>

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        userList = UserModel.getAll()
        setRecyclerView()
    }

     private fun setRecyclerView() {
         rvList.layoutManager = LinearLayoutManager(applicationContext, RecyclerView.VERTICAL, false)
         rvList.setHasFixedSize(true)
         rvList.adapter = UserAdapter(this, userList) {
             val intent = Intent(this, DetailActivity::class.java)
                 intent.putExtra(EXTRA_PARCELDATA, it)
             startActivity(intent)
         }
    }
}
